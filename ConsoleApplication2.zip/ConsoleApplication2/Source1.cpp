#include <iostream>
using namespace std;
int occur(char a[], int n, char y) {
    int d = 0;
    for (int i = 0; i < n; ++i) {
        if (a[i] == y)
            ++d;
    }
    return d;
}

int main() {
    int n;
    char y, a[100];
    cin >> n >> y;
    for (int i = 0; i < n; ++i) {
        cin >> a[i];
    }
    
    cout << occur(a, n, y);
    return 0;
}